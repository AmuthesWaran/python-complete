# levenshtein-cpp
A small levenshtein algorithm in cpp
